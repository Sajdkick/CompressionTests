#!/bin/sh
/c/android-ndk-r8d/ndk-build
cp libs/armeabi/libETCPlugin.so ../../../Assets/Plugins/Android/libETCPlugin.so
cp libs/armeabi-v7a/libETCPlugin.so ../../../Assets/Plugins/Android/libETCPluginARMv7.so
